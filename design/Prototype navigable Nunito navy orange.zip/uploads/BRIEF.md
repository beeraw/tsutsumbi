# Brief de création — interface tsutsumbi

Destiné à Claude Design. Objectif : refaire toute la création visuelle de
l'interface. Ce document décrit le produit, les données réelles, les contraintes
techniques qui ne sont pas négociables, et ce qui est attendu en sortie.

Le dossier `current/` contient des captures de l'interface actuelle et sa
feuille de style. Elles servent de point de départ à critiquer, pas de gabarit à
respecter.

---

## 1. Ce qu'est tsutsumbi

Un outil de suivi de projet de type Jira, avec une particularité : **il est
alimenté automatiquement par des agents** (Claude Code, Claude Design…) plutôt
que saisi à la main. Le travail est réparti sur une trentaine de projets et des
centaines de sessions de conversation ; l'historique de ce qui a été fait, de ce
qui est en cours et de ce qui a été abandonné se dilue. tsutsumbi est la mémoire
longue de ce travail.

Trois principes gouvernent le produit, et doivent se lire dans l'interface :

1. **L'agent est autonome.** Il crée les projets, ouvre les tickets, change les
   statuts, choisit les résolutions et ferme les tickets sans validation
   humaine. Rien dans l'interface ne doit ressembler à une file d'attente de
   validation ou à un formulaire de saisie principal.
2. **L'humain est en surplomb.** Il consulte, cherche, filtre, commente,
   corrige, réouvre, archive. Son geste dominant est **la lecture et le
   repérage**, pas la création. L'interface est d'abord un instrument de
   consultation.
3. **Rien ne se perd.** Un ticket abandonné reste consultable, un changement de
   statut laisse une trace. L'outil n'efface pas, il archive. Rien ne doit
   suggérer une suppression.

**Le nom.** *tsoutsoumbi* est un petit insecte de Mayotte. Insecte → bug →
gestion de projet. La marque est cet insecte, en orange (`#DE8A2A`), fournie dans
`assets/tsutsumbi-mark.svg`.

---

## 2. Qui regarde, et quand

Un seul utilisateur humain aujourd'hui : le développeur qui pilote les agents.
Il ouvre tsutsumbi dans deux situations, très différentes l'une de l'autre :

- **« Où j'en suis ? »** — En début ou en fin de journée. Il balaie la liste des
  projets, repère ce qui a bougé, ce qui est bloqué. Lecture rapide, beaucoup de
  lignes, peu de clics. C'est le cas d'usage dominant.
- **« Qu'est-ce qui s'est passé sur ce ticket ? »** — Trois mois plus tard,
  souvent. Il cherche une décision de conception prise à l'époque. Lecture lente
  et attentive d'un fil chronologique.

Écran de travail : **grand moniteur, 1920 px et au-delà**. C'est le contexte
principal. Une consultation ponctuelle sur portable arrive, sur mobile presque
jamais — mais l'interface ne doit pas casser.

---

## 3. Ce qui ne va pas dans l'existant

À traiter explicitement :

**La largeur est gâchée.** Tout est enfermé dans une colonne centrale de 68 rem
(~1090 px) centrée. Sur un écran 1920 px, plus de 40 % de la surface est du vide
gris de chaque côté, pendant que la liste des tickets tronque ses colonnes et
que le fil chronologique est à l'étroit. **Il faut prendre tout l'écran.**

**Les filtres sont une barre horizontale au-dessus du tableau.** Ils mangent de
la hauteur, se serrent quand il y en a plus de quatre, et n'ont nulle part où
grandir.

**L'ensemble fait « page web » plutôt qu'« outil ».** Cartes empilées,
respiration généreuse, peu de densité. Pour un instrument qu'on consulte
plusieurs fois par jour et qui affiche des listes, la densité est une qualité,
pas un défaut.

---

## 4. Direction demandée

**Moderne, orienté gestion de projet.** L'ambition est un outil qui tient la
comparaison avec Linear, Height ou Jira récent, sans les imiter.

**Plein écran.** Pas de colonne centrée. La navigation, la liste et le détail
occupent la largeur disponible. À charge au design de dire comment : rail latéral
fixe, barre supérieure pleine largeur, ou autre — c'est une décision de
conception attendue, argumentée.

**Recherche à droite, résultats à gauche.** C'est le pattern retenu, repris de
KDS, l'autre projet de la maison : sur les écrans de liste, les résultats
occupent les deux tiers gauche et une carte « filtres » est ancrée dans le tiers
droit, avec les champs empilés verticalement et un bouton d'application. Ce
placement est demandé explicitement, ce n'est pas une piste parmi d'autres.

**Densité assumée sur les listes.** Un projet peut porter des centaines de
tickets. Il faut pouvoir en lire trente d'un coup d'œil sans scroller, et
distinguer un `bloqué` d'un `en cours` sans lire le texte.

---

## 5. Les écrans

### 5.1 Connexion

Le seul écran public. Champs : adresse e-mail, mot de passe, « rester
connecté ». Une erreur possible : identifiants invalides. Le formulaire est
limité à 5 tentatives par quart d'heure — un message le dit quand ça arrive.

### 5.2 Tableau de bord — liste des projets

Une ligne par projet, **triées par activité décroissante**. Données réelles
disponibles pour chaque ligne :

| Donnée | Exemple | Remarque |
|---|---|---|
| Clé | `MAJI` | 1 à 10 caractères, majuscules et chiffres |
| Nom | `Maji` | jusqu'à 120 caractères |
| Chemin | `/Users/jeanluc/www/maji` | jusqu'à 500 caractères, souvent long |
| Tickets actifs | `7` | entier, souvent 0 |
| Dernière activité | `27 juil. 2026, 17:35` | |
| Archivé | booléen | masqué par défaut, affichable |

Une trentaine de projets aujourd'hui. Ce qu'on cherche ici : **repérer en une
seconde les projets qui ont bougé et ceux qui ont des tickets bloqués.** Le
nombre de tickets actifs seul ne dit pas s'il y a un blocage — c'est une
information qui manque aujourd'hui et qu'il serait bon de faire apparaître.

### 5.3 Projet — liste des tickets

Résultats à gauche, filtres à droite.

Filtres disponibles : recherche plein texte (titre, description **et corps des
commentaires**), statut, type, résolution, et une bascule « inclure les tickets
clos ». Les tickets clos sont masqués par défaut.

Colonnes disponibles par ticket :

| Donnée | Valeurs |
|---|---|
| Clé | `MAJI-42` |
| Titre | jusqu'à 200 caractères, souvent 40 à 80 |
| Type | `feature` `bug` `chore` `refactor` `docs` `infra` |
| Statut | `todo` `in_progress` `blocked` `done` |
| Résolution | `fixed` `wont_do` `abandoned` `duplicate` `obsolete` — uniquement si clos |
| Priorité | `low` `normal` `high` |
| Ouvert par | un agent ou un humain, voir §6 |
| Mis à jour | date et heure |

En-tête de l'écran : nom du projet, clé, chemin absolu, et l'action archiver.

Pagination : 25 par page.

### 5.4 Ticket — le détail

L'écran de lecture lente. Il contient :

- **En-tête** : clé, titre, et le couple statut + résolution.
- **Description** en markdown rendu : paragraphes, listes, `code`, blocs de
  code, citations, gras, liens.
- **Fil chronologique** : c'est la pièce maîtresse. Il fusionne deux natures
  d'entrées dans une seule chronologie :
  - les **commentaires**, du markdown écrit par un agent ou un humain ;
  - les **changements**, issus du journal d'audit : `Statut : à faire → en
    cours`, `Résolution : vide → fait`, `Titre : … → …`. Plusieurs champs
    modifiés ensemble forment une seule entrée. Une réécriture de description est
    signalée comme telle sans afficher le texte.
- **Métadonnées** : type, priorité, ouvert par, ouvert le, démarré le, clos le.
- **Pièces jointes**, quand il y en a — rares par conception. Nom, type, taille,
  date.
- **Actions** : modifier le ticket (titre, description, type, priorité), changer
  le statut (statut, résolution, commentaire), ajouter un commentaire.

Une contrainte du modèle qui doit se voir : **la résolution n'existe que sur un
ticket clos.** Passer en `bloqué` exige un commentaire expliquant la cause.
Rouvrir un ticket n'est pas une action à part : c'est un changement de statut qui
quitte `terminé`, et la résolution disparaît d'elle-même.

### 5.5 Jetons d'API

Écran d'administration, peu visité. Liste des jetons (sélecteur, libellé, agent,
portées, dernière utilisation, état) et un formulaire de création.

Un moment particulier à traiter : **à la création, le jeton en clair est affiché
une seule fois et ne le sera plus jamais.** Ce moment mérite un traitement visuel
qui dit « copiez ça maintenant » sans ambiguïté.

---

## 6. Distinguer les acteurs

Exigence du produit : **l'interface distingue visuellement les actions humaines
des actions d'agent, et distingue les agents entre eux.**

Chaque agent porte un slug (`claude-code`, `claude-design`, `claude-review`, et
d'autres apparaissent tout seuls), un libellé et une couleur assignée
automatiquement dans une palette de huit. Un humain est identifié par son e-mail.

La distinction ne doit pas reposer sur la seule couleur : elle doit tenir en
noir et blanc et pour un œil qui ne distingue pas les teintes. La solution
actuelle — un rond pour l'agent, un losange pour l'humain — est une piste, pas
une obligation.

---

## 7. Contraintes techniques, non négociables

Elles ne sont pas des préférences : elles sont déjà en place et le design doit
composer avec.

**Twig côté serveur, JavaScript vanilla, aucune étape de compilation.** Pas de
React, pas de Tailwind, pas de Sass, pas de bundler. Une feuille CSS écrite à la
main, servie telle quelle. Le CSS moderne est bienvenu : variables
personnalisées, grid, `color-mix()`, `:has()`.

**Content-Security-Policy stricte.** Aucun script inline, aucun bloc `<style>`,
aucune ressource distante — ni police Google, ni CDN, ni image externe. Tout est
servi depuis la même origine. Seuls les attributs `style` sont tolérés, pour
poser la couleur d'un acteur.

**Typographie Nunito**, déjà auto-hébergée en variable (400 à 700), latin et
latin étendu. Changer de police signifie l'auto-héberger aussi ; le dire si
c'est proposé.

**Palette navy, orange rare.** Navy `#1b2a4a` pour le chrome. L'orange `#DE8A2A`
est la couleur de la marque : aujourd'hui il ne sert qu'au logo et à l'anneau de
focus. Ce parti pris — une seule couleur saturée, dépensée avec parcimonie — est
à conserver ou à remettre en cause explicitement.

**`border-radius` de 0,2 rem.** Valeur imposée par la spécification.

**L'interface doit fonctionner sans JavaScript.** Le JS n'apporte que du
confort : soumission d'un filtre au changement, confirmation avant une action
destructrice, masquage du champ résolution quand le statut ne le porte pas.
Chaque règle est aussi appliquée côté serveur.

**Français.** Toute chaîne visible passe par le système de traduction ; les
libellés existants sont dans `translations/messages.fr.yaml`.

---

## 8. États à couvrir

Un design qui ne traite que le cas nominal ne sert à rien. À prévoir :

- **Vide** : aucun projet suivi, aucun ticket, aucun commentaire, aucun jeton. Le
  vide initial mérite une phrase qui explique ce qui va le remplir.
- **Trop plein** : un projet à 400 tickets, un fil chronologique à 60 entrées, un
  chemin de 200 caractères, un titre de 200 caractères.
- **Erreurs de formulaire** : champ invalide, et le cas particulier du refus
  métier — passer en bloqué sans commentaire, clore sans résolution.
- **Messages flash** : succès après une action, erreur de connexion.
- **Archivé et clos** : présents mais en retrait, jamais absents.

---

## 9. Livrables attendus

1. **Les quatre écrans principaux maquettés** en pleine largeur (1920 px et
   1440 px) : tableau de bord, projet, ticket, jetons. Plus la connexion.
2. **Le comportement en dessous de 1200 px** : ce que devient la colonne de
   filtres, ce que devient le tableau. Une règle, pas cinq points de rupture.
3. **Un système** plutôt qu'un ensemble d'écrans : échelle typographique,
   échelle d'espacement, jeu de couleurs avec les valeurs, traitement des
   statuts et des types, traitement des acteurs, états d'un champ, états d'un
   bouton.
4. **Le CSS**, ou de quoi l'écrire sans ambiguïté. Il remplacera
   `current/app.css`, dont la structure des classes peut servir de base ou être
   jetée.
5. **Ce qui a été écarté et pourquoi.** Les décisions non évidentes comptent
   autant que le résultat.

---

## 10. Questions ouvertes, sur lesquelles un avis est attendu

- Navigation : rail latéral permanent ou barre supérieure ? Le produit n'a que
  deux destinations de premier niveau (projets, jetons) — un rail est-il
  justifié, ou un luxe ?
- Le tableau de bord doit-il rester un tableau, ou devenir autre chose quand on
  suit trente projets dont vingt dorment ?
- Comment faire apparaître qu'un projet a des tickets **bloqués**, et pas
  seulement des tickets actifs ?
- Le fil chronologique mélange des entrées de deux natures très différentes
  (texte long / changement d'une ligne). Faut-il les traiter comme deux objets
  visuels distincts, ou les unifier ?
- Un mode sombre a-t-il un sens ici ? Il n'est pas demandé, il n'est pas exclu.
